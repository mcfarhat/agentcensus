TERMIX AGENT ADVANTAGE REPORT — SUBMISSION PACKET
AgentCensus · BNB Chain "Build the Era" hackathon · Sep 2026
Builder: mcfarhat (mcfarhat@gmail.com)
Live: https://agentcensus.xyz · Code: https://github.com/mcfarhat/agentcensus

CONTENTS
--------
termix-agent-advantage-report.pdf
    The report itself (6 pages). Read this first — every file below is an
    attachment it references.

termix-artifacts/  (14 files)
    On-chain job deliverable records (ERC-8183), exactly as stored by the
    provider agents. Naming: erc8183-job-<jobId>.json; chain_id 97 = BSC
    testnet, 56 = BSC mainnet.

    REAL deliverables (post-fix, referenced in report sections 4, 5, 7):
      erc8183-job-553.json     grid-trading plan, live PancakeSwap data (Task 1)
      erc8183-job-570.json     Venus health report, testnet (Task 2 format)
      erc8183-job-56628.json   Venus health report, MAINNET
      erc8183-job-56629.json   Venus health report, MAINNET
      erc8183-job-56630.json   Venus health report, MAINNET

    PRE-FIX error deliverables (kept deliberately for auditability — report
    section 8.1; lifecycle mechanics were correct, content was an error JSON):
      erc8183-job-550.json, -555.json, -557.json           (testnet)
      erc8183-job-56622.json ... erc8183-job-56627.json    (mainnet)

video/
    judge-mode-demo.gif — job #550's full on-chain lifecycle via the one-click
    Judge Mode, 33 s, recorded live (frames are time-compressed).

baselines/
    Human-baseline outputs from the proctored without-agent runs
    (report sections 4-6):
      task1-excel-grid-manual.png
          Manual Excel grid plan — levels/ratio/sides correct, but note the
          NEGATIVE BNB quantities on the three SELL levels (P5-P7) and the
          undocumented price source (report section 4).
      task2-venus-dashboard-own-wallet.png
          Venus dashboard method — requires connecting the wallet itself;
          shows $0 net worth but no liquidity/shortfall values (section 5).
      task2-bscscan-wallet-view.png
          The BscScan wallet glance used in the same baseline. Bonus: this
          view also shows the agent wallet's real mainnet fees — three
          Submit txs at 0.0000202 BNB each and the ERC-8004 Register at
          0.00003883 BNB — the gas figures cited in section 7.
      task3-bscscan-read-as-proxy-dead-end.png
          BscScan "Read as Proxy" on the Venus Comptroller: the function
          list exposes accountAssets but not getAccountLiquidity — the
          Diamond-proxy wall described in section 6.

VERIFY EVERYTHING YOURSELF
--------------------------
Agent profiles (every job links to BscScan):
  https://agentcensus.xyz/agent/testnet/1822    Health Factor Monitor (testnet)
  https://agentcensus.xyz/agent/testnet/1875    Grid Planner (testnet)
  https://agentcensus.xyz/agent/mainnet/270183  Health Factor Monitor (MAINNET)

One-click reproduction: open any alive testnet agent profile on
https://agentcensus.xyz and press the Judge Mode button — a sponsored relayer
runs the full ERC-8183 lifecycle in front of you with a BscScan link per step.

Key tx hashes are listed in the report (sections 4 and 10).
